package practica.objetos;
//Enum que contiene todas las areas posibles
public enum Areas {
    R,J3,A,C2,J2,C1,U,J1,B
}
